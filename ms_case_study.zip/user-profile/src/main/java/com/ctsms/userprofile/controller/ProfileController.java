package com.ctsms.userprofile.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ctsms.userprofile.dto.UserProfile;
import com.ctsms.userprofile.exception.CustomException;
import com.ctsms.userprofile.service.ProfileService;
import com.ctsms.userprofile.utils.ValidEmail;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {
	
	@Autowired
	ProfileService profileService;
	
	@PutMapping
	public ResponseEntity<?> updateUserProfile(@RequestBody @Valid UserProfile userProfile) throws CustomException {
		profileService.updateProfile(userProfile);
		return ResponseEntity.status(HttpStatus.CREATED).body("Profile updated successfully.");
	}

	@GetMapping("/{useremail}")
	public ResponseEntity<?> getUserProfile(@PathVariable("useremail") @ValidEmail String useremail) throws CustomException{
		Optional<UserProfile> profile = profileService.getUserByEmail(useremail);
		if(profile.isPresent()) {
		return ResponseEntity.status(HttpStatus.OK).body(profile.get());
		}else {
			throw new CustomException("Profile not found.");
		}
	}
}

package com.ctsms.userprofile.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ctsms.userprofile.dto.User;
import com.ctsms.userprofile.dto.UserProfile;
import com.ctsms.userprofile.exception.CustomException;
import com.ctsms.userprofile.repo.ProfileRepository;
import com.ctsms.userprofile.repo.UserRepository;


@Service
public class ProfileServiceImpl implements ProfileService {

	@Autowired
	private ProfileRepository profileRepository;
	
	@Autowired
	private UserRepository userRepo;
	
	@Override
	public UserProfile updateProfile(UserProfile user) throws CustomException{
		Optional<User> optional = userRepo.findById(user.getEmail());
		if(optional.isEmpty()) {
			throw new CustomException("Profile not found.");
		}
		return profileRepository.save(user);
	}

	@Override
	public Optional<UserProfile> getUserByEmail(String email) {
		return profileRepository.findById(email);
	}




}

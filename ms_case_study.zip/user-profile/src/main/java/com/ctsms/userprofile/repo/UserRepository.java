package com.ctsms.userprofile.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ctsms.userprofile.dto.User;

public interface UserRepository extends JpaRepository<User, String> {

}

package com.ctsms.userprofile.dto;

import com.ctsms.userprofile.utils.ValidEmail;
import com.ctsms.userprofile.utils.ValidPhone;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.Data;

@Data
@Entity
public class ContactDetails {
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@ValidPhone
	private String phone;
	
	@ValidEmail
	private String email;
	
	@OneToOne(mappedBy = "contactDetails")
	private UserProfile userProfile;
}

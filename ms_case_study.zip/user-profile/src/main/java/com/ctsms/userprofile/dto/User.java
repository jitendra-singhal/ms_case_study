package com.ctsms.userprofile.dto;

import com.ctsms.userprofile.*;
import com.ctsms.userprofile.utils.ValidEmail;
import com.ctsms.userprofile.utils.ValidPassword;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class User {
	
	@Id
	@ValidEmail
	private String email;
	
	@ValidPassword
	private String password;

}

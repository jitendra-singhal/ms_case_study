package com.ctsms.authentication.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ctsms.authentication.dto.LoginResponse;
import com.ctsms.authentication.dto.User;
import com.ctsms.authentication.exception.CustomException;
import com.ctsms.authentication.exception.EmailAlreadyExistsException;
import com.ctsms.authentication.service.AuthenticationService;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;
import jakarta.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api")
public class AuthenticationController {
	
	@Autowired
	private AuthenticationService authenticationService;
	
	@PostMapping("/register")
	public ResponseEntity<?> register(@RequestBody @Valid User user) throws EmailAlreadyExistsException, CustomException, AddressException, MessagingException{
		String registrationResponse = authenticationService.register(user);
		return ResponseEntity.status(HttpStatus.CREATED).body(registrationResponse);
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody @Valid User login) throws CustomException{		

		LoginResponse response = authenticationService.login(login);
	
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

}

package com.ctsms.authentication.response.error;

import lombok.Data;

@Data
public class ErrorResponse {
	private String errorMessage;

}

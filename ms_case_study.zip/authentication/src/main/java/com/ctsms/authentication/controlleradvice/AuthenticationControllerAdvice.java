package com.ctsms.authentication.controlleradvice;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.ctsms.authentication.exception.CustomException;
import com.ctsms.authentication.exception.EmailAlreadyExistsException;
import com.ctsms.authentication.response.error.ErrorResponse;

@ControllerAdvice
public class AuthenticationControllerAdvice {
	
	@ExceptionHandler(EmailAlreadyExistsException.class)
	public ResponseEntity<?> handleMethodArgumentTypeMismatchException(EmailAlreadyExistsException e){
		
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorMessage(e.getMessage());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
	}
	
	@ExceptionHandler(CustomException.class)
	public ResponseEntity<?> handleCustomException(CustomException e){
		
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorMessage(e.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> handleMethodArgumentNotValidException(MethodArgumentNotValidException e){
		List<String> errorList = new ArrayList<>();
		e.getFieldErrors().forEach(err -> errorList.add(err.getDefaultMessage()));
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorList);
	}

}

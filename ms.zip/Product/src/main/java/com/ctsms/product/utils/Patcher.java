package com.ctsms.product.utils;

import java.lang.reflect.Field;

import org.springframework.stereotype.Component;

import com.ctsms.product.model.Product;

@Component
public class Patcher {

	public void productPatcher(Product existingProduct, Product updatedPatch) throws IllegalAccessException {

        //GET THE COMPILED VERSION OF THE CLASS
        Class<?> productClass= Product.class;
        Field[] internFields=productClass.getDeclaredFields();
        System.out.println(internFields.length);
        for(Field field : internFields){
            System.out.println(field.getName());
            //CANT ACCESS IF THE FIELD IS PRIVATE
            field.setAccessible(true);

            //CHECK IF THE VALUE OF THE FIELD IS NOT NULL, IF NOT UPDATE EXISTING INTERN
            Object value=field.get(updatedPatch);
            if(value!=null){
                field.set(existingProduct,value);
            }
            //MAKE THE FIELD PRIVATE AGAIN
            field.setAccessible(false);
        }

    }
}

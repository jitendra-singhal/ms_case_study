package com.ctsms.product.response.error;

import lombok.Data;

@Data
public class ErrorResponse {
	private String errorMessage;

}

package com.ctsms.product.controlleradvice;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.ctsms.product.exception.CustomException;
import com.ctsms.product.exception.ResourceNotFoundException;
import com.ctsms.product.response.error.ErrorResponse;

@ControllerAdvice
public class ProfileControllerAdvice {
	
	
	@ExceptionHandler(CustomException.class)
	public ResponseEntity<?> handleCustomException(CustomException e){
		
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorMessage(e.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> handleMethodArgumentNotValidException(MethodArgumentNotValidException e){
		List<String> errorList = new ArrayList<>();
		e.getFieldErrors().forEach(err -> errorList.add(err.getDefaultMessage()));
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorList);
	}
	
	
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<?> handleResourceNotFoundException(ResourceNotFoundException e){
		
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorMessage(e.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
	}
	
}

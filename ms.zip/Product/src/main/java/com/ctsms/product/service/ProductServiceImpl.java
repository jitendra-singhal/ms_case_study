package com.ctsms.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ctsms.product.exception.CustomException;
import com.ctsms.product.exception.ResourceNotFoundException;
import com.ctsms.product.model.Product;
import com.ctsms.product.repository.ProductRepository;
import com.ctsms.product.utils.Patcher;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductRepository repository;
	
	@Autowired
	private Patcher productPatcher;

	@Override
	public List<Product> getAllProducts() {
		return repository.findAll();
	}

	@Override
	public List<Product> getProductsByCategory(String category) {
		return repository.findByCategory(category);
	}

	@Override
	public Optional<Product> findById(Integer id) {
		return repository.findById(id);
	}

	@Override
	public List<Product> findBySearchText(String searchText) {
		return repository.getProductsBySearch(searchText);
	}

	@Override
	public Product saveProduct(Product product) {
		return repository.save(product);
	}

	@Override
	public void deleteProduct(Integer productId) throws ResourceNotFoundException, CustomException {
		Optional<Product> optional = findById(productId);
		if(optional.isEmpty()) {
			throw new ResourceNotFoundException("No product found for the give id.");
		}
		try {
		repository.deleteById(productId);
		}catch (Exception e) {
			throw new CustomException("unable to delete product. Please try again later.");
		}
		
	}

	@Override
	public Product updateProduct(Integer productId, Product product) throws IllegalAccessException, ResourceNotFoundException {
		Optional<Product> optional = findById(productId);
		if(optional.isEmpty()) {
			throw new ResourceNotFoundException("No product found for the give id.");
		}
		productPatcher.productPatcher(optional.get(), product);
		return repository.save(optional.get());
	}

}

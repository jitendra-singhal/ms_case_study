package com.ctsms.product.service;

import java.util.List;
import java.util.Optional;

import com.ctsms.product.exception.CustomException;
import com.ctsms.product.exception.ResourceNotFoundException;
import com.ctsms.product.model.Product;

public interface ProductService {
	
	public List<Product> getAllProducts();
	public List<Product> getProductsByCategory(String category);
	public Optional<Product> findById(Integer id);
	public List<Product> findBySearchText(String searchText);

	//product inventory management operations
	public Product saveProduct(Product product);
	public Product updateProduct(Integer productId, Product product) throws IllegalAccessException, ResourceNotFoundException;
	public void deleteProduct(Integer productId) throws ResourceNotFoundException, CustomException;
	
    
}

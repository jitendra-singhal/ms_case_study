package com.ctsms.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ctsms.product.exception.CustomException;
import com.ctsms.product.exception.ResourceNotFoundException;
import com.ctsms.product.model.Product;
import com.ctsms.product.service.ProductService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/products")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping
	public ResponseEntity<?> getAllProducts() throws ResourceNotFoundException{
		List<Product> response = productService.getAllProducts();
		if(response != null && !response.isEmpty()) {
		return ResponseEntity.status(HttpStatus.OK).body(response);
		}else {
			throw new ResourceNotFoundException("Unable to fetch products.");
		}
		
	}
	
	@GetMapping("/category/{category}")
	public ResponseEntity<?> getAllProductsByCategory(@PathVariable("category") String category) throws ResourceNotFoundException{
		List<Product> response = productService.getProductsByCategory(category);
		if(response != null && !response.isEmpty()) {
		return ResponseEntity.status(HttpStatus.OK).body(response);
		}else {
			throw new ResourceNotFoundException("Unable to fetch products for the given category.");
		}
	}
	
	@GetMapping("/search")
	public ResponseEntity<?> searchProducts(@RequestParam("q") String searchTerm) throws CustomException{
		List<Product> response = productService.findBySearchText(searchTerm);
		if(response != null && !response.isEmpty()) {
		return ResponseEntity.status(HttpStatus.OK).body(response);
		}else {
			throw new CustomException("Unable to perform product search.");
		}
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> getProductDetails(@PathVariable("id") Integer id) throws ResourceNotFoundException{
		Optional<Product> optional = productService.findById(id);
		if(optional.isPresent()) {
			return ResponseEntity.status(HttpStatus.OK).body(optional.get());
					
		}else {
			throw new ResourceNotFoundException("Product not found.");
		}
	}
	
	
	//product inventory management apis
	
	@PostMapping
	public ResponseEntity<?> addProduct(@RequestBody Product product) throws CustomException{	
		Product response = productService.saveProduct(product);
		if(response != null) {
		return ResponseEntity.status(HttpStatus.CREATED).body("products saved");
		}else {
			throw new CustomException("Unable to save product.Please try again later.");
		}
	}
	
	
	@PatchMapping("{productId}")
	public ResponseEntity<?> updateProduct(@PathVariable("productId") Integer productId, @RequestBody Product updatedProduct) throws CustomException, IllegalAccessException, ResourceNotFoundException{	
		Product response = productService.updateProduct(productId, updatedProduct);
		if(response != null) {
		return ResponseEntity.status(HttpStatus.CREATED).body("products saved");
		}else {
			throw new CustomException("Unable to update product.Please try again later.");
		}
	}
	
	@DeleteMapping("{productId}")
	public ResponseEntity<?> deleteProduct(@PathVariable("productId") Integer productId) throws CustomException, ResourceNotFoundException{	
		productService.deleteProduct(productId);
		return ResponseEntity.status(HttpStatus.OK).body("Product deleted successfully");
	}
	

}
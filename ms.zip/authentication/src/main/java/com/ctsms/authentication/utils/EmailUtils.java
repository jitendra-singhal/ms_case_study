package com.ctsms.authentication.utils;

import java.util.Properties;
import java.util.UUID;

import org.springframework.stereotype.Component;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Multipart;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.AddressException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;

@Component
public class EmailUtils {

	Properties loadEmailProperties() {

		Properties prop = new Properties();
		prop.put("mail.smtp.auth", true);
		prop.put("mail.smtp.starttls.enable", "true");
		prop.put("mail.smtp.host", "sandbox.smtp.mailtrap.io");
		prop.put("mail.smtp.port", "2525");
		prop.put("mail.smtp.ssl.trust", "sandbox.smtp.mailtrap.io");
		return prop;
	}

	Message prepareEmailMessage(Session session) throws AddressException, MessagingException {
		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress("jsinghal773@gmail.com"));
		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("jsinghal773@gmail.com"));
		message.setSubject("Verification Email");

		String msg = "Please click on the below link to complete your registration process: </br>"
				+ " https://example.com/verify?token="+UUID.randomUUID().toString();

		MimeBodyPart mimeBodyPart = new MimeBodyPart();
		mimeBodyPart.setContent(msg, "text/html; charset=utf-8");

		Multipart multipart = new MimeMultipart();
		multipart.addBodyPart(mimeBodyPart);

		message.setContent(multipart);

		return message;
	}

	public void sendEmail() throws AddressException, MessagingException {

		Session session = Session.getInstance(loadEmailProperties(), new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("6fe1d504a1d3fe", "e238dac4c6927d");
			}
		});

		Message emailMessage = prepareEmailMessage(session);
		Transport.send(emailMessage);

		System.out.println("email sent");
	}

}

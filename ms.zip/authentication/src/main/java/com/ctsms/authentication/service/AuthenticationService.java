package com.ctsms.authentication.service;

import java.util.Optional;

import com.ctsms.authentication.dto.LoginResponse;
import com.ctsms.authentication.dto.User;
import com.ctsms.authentication.exception.CustomException;
import com.ctsms.authentication.exception.EmailAlreadyExistsException;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;

public interface AuthenticationService {
	public User registerUser(User user);
	public Optional<User> getUserByEmail(String email);
	public LoginResponse login(User user) throws CustomException;
	public String register(User user) throws EmailAlreadyExistsException, CustomException, AddressException, MessagingException;
}

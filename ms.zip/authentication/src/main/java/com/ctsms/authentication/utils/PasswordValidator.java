package com.ctsms.authentication.utils;

import java.util.regex.Pattern;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class PasswordValidator implements ConstraintValidator<ValidPassword, String>{

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		String regexPattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
		return patternMatches(value, regexPattern);
	}
	
	public static boolean patternMatches(String password, String regexPattern) {
	    return Pattern.compile(regexPattern)
	      .matcher(password)
	      .matches();
	}
	
}

package com.ctsms.authentication.service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ctsms.authentication.dto.LoginResponse;
import com.ctsms.authentication.dto.User;
import com.ctsms.authentication.exception.CustomException;
import com.ctsms.authentication.exception.EmailAlreadyExistsException;
import com.ctsms.authentication.repo.AuthenticationRepository;
import com.ctsms.authentication.utils.CryptoUtils;
import com.ctsms.authentication.utils.EmailUtils;
import com.ctsms.authentication.utils.JWTUtils;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.AddressException;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

	@Autowired
	private AuthenticationRepository authenticationRepository;
	
	@Autowired
	private CryptoUtils cryptoUtils;
	
	@Autowired
	private EmailUtils emailUtils;
	
	@Override
	public User registerUser(User user){
		user.setPassword(cryptoUtils.encrypt(user.getPassword()));
		return authenticationRepository.save(user);
	}

	@Override
	public Optional<User> getUserByEmail(String email) {
		return authenticationRepository.findById(email);
		
	}

	
	public LoginResponse login(User user) throws CustomException {
		Optional<User> dbUser = getUserByEmail(user.getEmail());
		if(dbUser.isEmpty() || !cryptoUtils.decrypt(dbUser.get().getPassword()).equals(user.getPassword())) {
			throw new CustomException("Invalid email or password.");
		}
		LoginResponse response = new LoginResponse();
		response.setMessage("Login successful.");
		LocalDateTime ldt = LocalDateTime.now().plusMinutes(15);
		response.setToken(new JWTUtils(user.getEmail(), user.getPassword(), ldt.toEpochSecond(ZoneOffset.UTC)).toString());
		
		return response;
	}
	
	
	public String register(User user) throws EmailAlreadyExistsException, CustomException, AddressException, MessagingException {
		if(getUserByEmail(user.getEmail()).isPresent()) {
			throw new EmailAlreadyExistsException("Email already exists.");
		}
		User savedUser = registerUser(user);
		
		if(savedUser != null) {
			emailUtils.sendEmail();
			return "egistration successful. Verification email sent.";
		}else {
			throw new CustomException("Registration failed. Please try again later.");
		}
	}



}

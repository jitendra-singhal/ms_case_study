package com.ctsms.authentication.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ctsms.authentication.dto.User;

public interface AuthenticationRepository  extends JpaRepository<User, String>{

}

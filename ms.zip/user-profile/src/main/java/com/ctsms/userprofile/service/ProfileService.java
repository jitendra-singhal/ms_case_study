package com.ctsms.userprofile.service;

import java.util.Optional;

import com.ctsms.userprofile.dto.UserProfile;
import com.ctsms.userprofile.exception.CustomException;


public interface ProfileService {
	public UserProfile updateProfile(UserProfile user) throws CustomException;
	public Optional<UserProfile> getUserByEmail(String email);
}

package com.ctsms.userprofile.dto;

import com.ctsms.userprofile.utils.ValidEmail;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@Entity
public class UserProfile {
	
	@Id
	@ValidEmail
	private String email;
	
	@NotBlank
	private String name;
	
	@NotBlank(message = "address can not be null or blank")
	private String address;
	
	@Valid
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "id", referencedColumnName = "id")
	private ContactDetails contactDetails;

}
